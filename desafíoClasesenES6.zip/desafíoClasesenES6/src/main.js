/// importar, o incluir las clases impuestos y cliente

import Impuesto from './impuesto.js'
import Cliente from './cliente.js'



let impProgramador = new Impuesto(3000000,100000);
let programador1 = new Cliente("Gustavo",impProgramador );

//console.log(impProgramador);
//console.log(programador1); 

programador1.calcularImpuesto();