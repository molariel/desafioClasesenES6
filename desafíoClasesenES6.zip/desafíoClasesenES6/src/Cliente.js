export default class Cliente {

    /// el constructor recibe estor parametros
    constructor(nombre,impuesto){
        this._nombre = nombre;
        this._impuesto = impuesto;
    }

    ///getter para atributo _nombre
     get nombre(){
        return this._nombre;
        }
    /// setter para atributo_ nombre
    set nombre(nuevoNombre){
        this._nombre= nuevoNombre;
            
    }

    ///metodo calcularImpuesto
    calcularImpuesto(){
        let impuesto;
        let mensaje;
        impuesto = (this._impuesto.montoBrutoAnual - this._impuesto.deducciones) * 0.21;
        mensaje = `El impuesto de ${this._nombre} es ${impuesto}`
        console.log(mensaje);
   
    }

}