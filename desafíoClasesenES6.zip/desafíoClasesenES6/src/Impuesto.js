export default class Impuesto{
    constructor(montoBrutoAnual, deducciones){
    this._montoBruto = montoBrutoAnual;
    this._deducciones = deducciones;
}
/// getter y setter del atributo_montoBrutoAnual
    get montoBrutoAnual(){
        return this._montoBrutoAnual;
    }  
    set montoBrutoAnual(nuevoMonto){
        this._montoBrutoAnual=nuevoMonto;
    }



// getter y setter del atributo_deducciones
get deducciones(){
    return this._deducciones;
}  
set deducciones(nuevoMonto){
    this._deducciones = nuevoMonto;
}
}
